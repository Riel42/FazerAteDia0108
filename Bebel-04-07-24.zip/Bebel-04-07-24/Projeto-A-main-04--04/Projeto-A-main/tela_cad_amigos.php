<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cadAmigos.css">
    <title>Tela de cadastro de amigos</title>
</head>
<body>
    <section id="cxprincipal">
        <h1>Tela de Cadastro de Amigos</h1>

        <header id="cxcadastro">
            <form action="inserir_amigo.php" method="post">
                <label for="amigo">Amigo: </label><br>
                <input type="text" name="amigo" id="amigo"><br>
                <label for="email">E-mail: </label><br>
                <input type="email" name="email" id="email"><br>
                <label for="telefone">Telefone: </label><br>
                <input type="text" name="telefone" id="telefone"><br>
                <label for="whatsapp">WhatsApp: </label><br>
                <input type="text" name="whatsapp" id="whatsapp"><br>
                <label for="datanasc">Data de Nascimento: </label><br>
                <input type="date" name="datanasc" id="datanasc"><br><br>
                <input type="submit" value="Cadastrar amigo!"><br>
            </form>
            <br><br>
            <div id="procurar">
                <!-- <hr size="5" color="" width="500"> -->
                <form action="consulta-amigo.php" method="post">
                    <label for="buscar-nome">Digite o nome do amigo:</label>
                    <input type="text" name="buscar-nome" id="buscar-nome">
                    <input type="submit" value="Buscar">
                </form>
            </div>
        </header>
        
    </section>
    
</body>
</html>