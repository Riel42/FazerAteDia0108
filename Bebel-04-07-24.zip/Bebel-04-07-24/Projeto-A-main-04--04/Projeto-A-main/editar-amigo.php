<?php 
    $codigo = $_GET["id"];
    if($_GET["id"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $consulta = "select * from tbamigos where codigo = '$codigo'";
        $executar = mysqli_query($conectar, $consulta);
        $linha = mysqli_fetch_array($executar);
        
        $amigo = $linha['amigo'];
        $email = $linha['email'];
        $telefone = $linha['telefone'];
        $whast = $linha['whast'];        
        $datanasc = $linha['datanasc'];

        echo $amigo;
    }
    else{
        echo "Não foi possível!";
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- FAZER O FORM AQUI -->
</body>
</html>