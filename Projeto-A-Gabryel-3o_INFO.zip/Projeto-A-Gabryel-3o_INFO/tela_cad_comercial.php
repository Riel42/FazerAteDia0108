<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cad-comercial.css">
    <title>Tela de cadastro de amigos</title>
</head>
<body>
    <section id="cxprincipal">
        <h1>Tela de Cadastro Comercial</h1>

        <header id="cxcadastro">
            <form action="inserir_comercial.php" method="post">
                <label for="nome">Nome: </label><br>
                <input type="text" name="nome" id="nome"><br>
                <label for="comercio">Comércio: </label><br>
                <input type="text" name="comercio" id="comercio"><br>
                <label for="telefone">Telefone: </label><br>
                <input type="text" name="telefone" id="telefone"><br>
                <label for="whatsapp">WhatsApp: </label><br>
                <input type="text" name="whatsapp" id="whatsapp"><br><br>
                <input type="submit" value="Cadastrar comércio!"><br>
            </form>
            <br><br>
            <div id="procurar">
                <!-- <hr size="5" color="" width="500"> -->
                <form action="consulta-comercio.php" method="post">
                    <label for="buscar-nome">Digite o comércio:</label>
                    <input type="text" name="buscar-nome" id="buscar-nome">
                    <input type="submit" value="Buscar">
                </form>
            </div>
        </header>
    </section>
</body>
</html>