<?php 
    include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php

    $codigo = $_POST["codigo"];
    $nome = $_POST["nome"];
    $comercio = $_POST["comercio"];
    $telefone = $_POST["telefone"];
    $whast = $_POST["whast"];

    $comando_sql = "UPDATE tbcomercial SET 
    nome = '$nome',
    comercio = '$comercio',
    telefone = '$telefone',
    whast = '$whast'
    where codigo = '$codigo'";

    $atualizar = mysqli_query($conectar, $comando_sql);

    echo "Linha editada no banco de dados com sucesso!" . "<br>";
    header('Location: tela_menu.php');
?>
