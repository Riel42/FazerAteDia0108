<?php 
    $codigo = $_GET["id"];
    if($_GET["id"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php

    
        $comando_sql = "DELETE FROM tbcomercial WHERE codigo = '$codigo' ";

        $excluir = mysqli_query($conectar, $comando_sql); 
        //Primeiro conectará no BD e depois ele vai executar o comando 

        echo "Linha excluída no banco de dados com sucesso!" . "<br>";
        header("Location: tela_menu.php");
    }
    else{
        echo "Não foi possível!";
    }
?>