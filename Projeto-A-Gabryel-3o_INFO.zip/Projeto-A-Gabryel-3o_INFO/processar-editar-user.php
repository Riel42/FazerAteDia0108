<?php 
    include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php

    $cod = $_POST["cod"];
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $comando_sql = "UPDATE tbusuario SET 
    nome = '$nome',
    email = '$email',
    senha = '$senha'
    where cod = '$cod'";

    $atualizar = mysqli_query($conectar, $comando_sql);

    echo "Linha editada no banco de dados com sucesso!" . "<br>";
    header('Location: tela_menu.php');
?>
