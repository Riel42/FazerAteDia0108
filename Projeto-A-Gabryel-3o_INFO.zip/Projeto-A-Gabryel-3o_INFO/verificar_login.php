<?php
require_once "factory/conexao.php";
session_start();

$email = $_POST["email"]; //receberá o e-mail
$senha = $_POST["senha"]; //receberá a senha

$sql = "SELECT * FROM tbusuario WHERE email = '$email' AND senha = '$senha'";

$result = mysqli_query($conectar, $sql);

if (mysqli_num_rows($result)== 1) { //Se encontrar um resultado
    $_SESSION["email"] = $email;
    $_SESSION["senha"] = $senha;
    
    header("Location: tela_menu.php"); //redirecione para index.php
    exit();
}
?>