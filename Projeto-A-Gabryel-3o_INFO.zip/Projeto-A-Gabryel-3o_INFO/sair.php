<?php 
    session_start();
    session_unset();
    header('Location: tela_login.php');
?>