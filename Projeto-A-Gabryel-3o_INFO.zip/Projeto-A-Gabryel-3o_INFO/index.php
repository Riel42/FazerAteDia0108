<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela Inicial</title>
</head>
<body><!-- 

    OBS: O 'index.php' antigo era assim, mas agora ele joga diretamente para o 'menu'

    <h1>Ir para:</h1>
    <ul>
       <li><a href="cadastro_user.php">Tela de cadastro de user</a></li>
       <li><a href="tela_cad_amigos.php">Tela de cadastro de amigo</a></li>
       <li><a href="tela_cad_comercial.php">Tela de cadastro comercial</a></li>
       <li><a href="tela_login.php">Tela de login</a></li>
       <li><a href="tela_menu.php">Tela de menu</a></li>
    </ul>-->
    
</body>
</html>

<?php header("location: tela_login.php"); ?>