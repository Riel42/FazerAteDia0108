<?php 
    $codigo = $_GET["id"];
    if($_GET["id"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $consulta = "select * from tbamigos where codigo = '$codigo'";
        $executar = mysqli_query($conectar, $consulta);
        $linha = mysqli_fetch_array($executar);
        
        $amigo = $linha['amigo'];
        $email = $linha['email'];
        $telefone = $linha['telefone'];
        $whast = $linha['whast'];        
        $datanasc = $linha['datanasc'];
    }
    else{
        echo "Não foi possível!";
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cadAmigos.css">
    
    <title>Document</title>

    <?php
        session_start();

        echo $_SESSION['email'];
        if(isset ($_SESSION['email']) and isset ($_SESSION['senha'])){
            $logado = $_SESSION['email'];
        }
        else{
            header('Location: tela_login.php');
        }
    ?>
</head>
<body>
<div id="cxinfo2">
    <br>
    <form action="processar-editar-amigo.php" method="POST">

    <label for="nome">Nome do amigo: </label>
    <input type="text" id="amigo" name="amigo" placeholder="<?php echo $amigo ?>" value="<?php echo $amigo ?>" required><br><br>

    <label for="nome">E-mail do amigo: </label>
    <input type="email" id="email" name="email" placeholder="<?php echo $email ?>" value="<?php echo $email ?>" required><br><br>

    <label for="nome">Telefone do amigo: </label>
    <input type="text" id="telefone" name="telefone" placeholder="<?php echo $telefone ?>" value="<?php echo $telefone ?>" required><br><br>

    <label for="nome">WhatsApp do amigo: </label>
    <input type="text" id="whast" name="whast" placeholder="<?php echo $whast ?>" value="<?php echo $whast ?>" required><br><br>

    <label for="nome">Data de nasc. do amigo: </label>
    <input type="date" id="datanasc" name="datanasc" placeholder="<?php echo $datanasc ?>" value="<?php echo $datanasc ?>" required><br><br>

    <input type="hidden" name="codigo" placeholder="<?php echo $codigo ?>" value="<?php echo $codigo ?>">

    <input type="submit" value="enviar">
    </form>
</div>
</body>
</html>