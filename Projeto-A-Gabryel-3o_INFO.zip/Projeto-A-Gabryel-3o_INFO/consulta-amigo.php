<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cadAmigos.css">
    <title>Consulta do amigo</title>

    <?php
        session_start();

        echo $_SESSION['email'];
        if(isset ($_SESSION['email']) and isset ($_SESSION['senha'])){
            $logado = $_SESSION['email'];
        }
        else{
            header('Location: tela_login.php');
        }
    ?>
</head>
<body>
    <div id="cxinfo">
    <?php 
        include_once "factory/conexao.php";
        $nome = $_POST['buscar-nome'];
        $consulta = "select * from tbamigos where amigo = '$nome'";
        $executar = mysqli_query($conectar, $consulta);
        $linha = mysqli_fetch_array($executar);
    ?>

    <?php 
        if($linha['amigo'] == ""){
            echo "<br>O dado consultado não foi encontrado.";

        }
        else{
            echo "<br>";
            echo "Nome: " . $linha['amigo'] . "<br>";
            echo "E-mail: " . $linha['email'] . "<br>"; 
            echo "Telefone: " . $linha['telefone'] . "<br>"; 
            echo "WhatsApp: " . $linha['whast'] . "<br>";
            echo "Data de Nasc.: " . $linha['datanasc'] . "<br>"; 
        }
    ?>
    <a style="color: red" href="editar-amigo.php?id=<?php echo $linha['codigo']?>">EDITAR</a> / 
    <a style="color: red" href="excluir-amigo.php?id=<?php echo $linha['codigo']?>">EXCLUIR</a>
    </div>
</body>
</html>