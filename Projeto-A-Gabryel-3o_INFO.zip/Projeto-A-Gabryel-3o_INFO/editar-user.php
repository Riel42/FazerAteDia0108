<?php 
    $cod = $_GET["id"];
    if($_GET["id"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $consulta = "select * from tbusuario where cod = '$cod'";
        $executar = mysqli_query($conectar, $consulta);
        $linha = mysqli_fetch_array($executar);
        
        $nome = $linha['nome'];
        $email = $linha['email'];
        $senha = $linha['senha'];
        
    }
    else{
        echo "Não foi possível!";
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style_cad.css">

    <?php
        session_start();

        echo $_SESSION['email'];
        if(isset ($_SESSION['email']) and isset ($_SESSION['senha'])){
            $logado = $_SESSION['email'];
        }
        else{
            header('Location: tela_login.php');
        }
    ?>
</head>
<body>
    <div id="cxinfo2">
    <br>
    <form action="processar-editar-user.php" method="POST">

    <label for="nome">Nome: </label>
    <input type="text" id="nome" name="nome" placeholder="<?php echo $nome ?>" value="<?php echo $nome ?>" required><br><br>

    <label for="email">E-mail: </label>
    <input type="email" id="email" name="email" placeholder="<?php echo $email ?>" value="<?php echo $email ?>" required><br><br>

    <label for="senha">Senha: </label>
    <input type="password" id="senha" name="senha" placeholder="<?php echo $senha ?>" value="<?php echo $senha ?>" required><br><br>

    <input type="hidden" name="cod" placeholder="<?php echo $cod ?>" value="<?php echo $cod ?>">

    <input type="submit" value="enviar">
    </form>
    </div>
</body>
</html>