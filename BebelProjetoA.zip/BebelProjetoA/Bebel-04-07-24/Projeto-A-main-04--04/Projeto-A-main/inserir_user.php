<?php 
    if($_POST["nome"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $passwd = $_POST["passwd"];

        $comando_sql = "insert into tbusuario(nome, email, senha) values('$nome', '$email', '$passwd')";

        $inserir = mysqli_query($conectar, $comando_sql); 
        //Primeiro conectará no BD e depois ele vai executar o comando 

        echo "Dados cadastrados com sucesso!";
        header('Location: index.php');
    }
    else{
        echo "Dados não cadastrados!";
    }
?>