<?php 
    include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php

    $codigo = $_POST["codigo"];
    $amigo = $_POST["amigo"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];
    $whast = $_POST["whast"];
    $datanasc = $_POST["datanasc"];

    $comando_sql = "UPDATE tbamigos SET 
    amigo = '$amigo',
    email = '$email',
    telefone = '$telefone',
    whast = '$whast',
    datanasc = '$datanasc'
    where codigo = '$codigo'";

    $atualizar = mysqli_query($conectar, $comando_sql);

    echo "Linha editada no banco de dados com sucesso!" . "<br>";
    echo "<a href='tela_menu.php'>Voltar para tela de menu</a>";
?>
