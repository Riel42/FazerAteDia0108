<?php 
    $codigo = $_GET["id"];
    if($_GET["id"] != ""){
        include_once 'factory/conexao.php'; //Inclui o codigo-fonte de conexao.php
        $consulta = "select * from tbcomercial where codigo = '$codigo'";
        $executar = mysqli_query($conectar, $consulta);
        $linha = mysqli_fetch_array($executar);
        
        $nome = $linha['nome'];
        $comercio = $linha['comercio'];
        $telefone = $linha['telefone'];
        $whast = $linha['whast'];  
        
    }
    else{
        echo "Não foi possível!";
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="processar-editar-comercio.php" method="POST">

    <label for="nome">Nome: </label>
    <input type="text" id="nome" name="nome" placeholder="<?php echo $nome ?>" value="<?php echo $nome ?>" required><br><br>

    <label for="comercio">Comércio: </label>
    <input type="text" id="comercio" name="comercio" placeholder="<?php echo $comercio ?>" value="<?php echo $comercio ?>" required><br><br>

    <label for="telefone">Telefone: </label>
    <input type="text" id="telefone" name="telefone" placeholder="<?php echo $telefone ?>" value="<?php echo $telefone ?>" required><br><br>

    <label for="whast">WhatsApp: </label>
    <input type="text" id="whast" name="whast" placeholder="<?php echo $whast ?>" value="<?php echo $whast ?>" required><br><br>

    <input type="hidden" name="codigo" placeholder="<?php echo $codigo ?>" value="<?php echo $codigo ?>">

    <input type="submit" value="enviar">
    </form>

</body>
</html>